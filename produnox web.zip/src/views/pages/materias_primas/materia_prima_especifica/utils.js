var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('dados_orcamento.sqlite3');
window.onload = function() 
{
    fornecedores();
    jq();
};
function cadastra()
{
    var dados = [];
    dados.push(document.getElementById("nome").value);
    if(document.getElementById("fornecedor").value != 0)
    {
        dados.push(document.getElementById("fornecedor").value);
    }
    else
    {
        alert("Selecione um fornecedor!");
        return;
    }
    dados.push(document.getElementById("unidade").value);
    dados.push(document.getElementById("quantidade").value);
    dados.push(document.getElementById("marca").value);
    dados.push(document.getElementById("valor_unitario").value);
    dados.push(document.getElementById("descricao").value);
    dados.push(document.getElementById("intervalo").value);
    dados.push(document.getElementById("demarcacao").value);
    db.run("INSERT INTO materia_prima (nome, fornecedor, unidade, quantidade, marca, valor_unitario, descricao, especifica, intervalo, demarcacao) VALUES"
    +"('"+dados[0]+"',"+dados[1]+",'"+dados[2]+"',"+dados[3]+",'"+dados[4]+"',"+dados[5]+",'"+dados[6]+"', 1, "+dados[7]+", '"+dados[8]+"');", ()=>
    {
        document.location.href = 'materias_primas.html';
        alert("Cadastrado!");
    });
}
function lista()
{
    var select = document.getElementById("lista");
    db.each("SELECT nome, codigo as id, marca FROM materia_prima where especifica = 1", function(err, row) 
    {
        var option = document.createElement("option");
        option.text = row.id+" - "+row.nome+" ("+row.marca+")";
        option.value = row.id;
        select.appendChild(option);
        faz_filtro_mp();
    });
}
function carrega_dados()
{
    var id = sessionStorage.getItem('id');
    db.each("SELECT * FROM materia_prima where codigo = "+id, function(err, row) 
    {
        document.getElementById("nome").value = row.nome;
        document.getElementById("fornecedor").value = row.fornecedor;
        document.getElementById("unidade").value = row.unidade;
        document.getElementById("quantidade").value = row.quantidade;
        document.getElementById("marca").value = row.marca;
        document.getElementById("valor_unitario").value = row.valor_unitario;
        document.getElementById("descricao").value = row.descricao;
        document.getElementById("intervalo").value = row.intervalo;
        document.getElementById("demarcacao").value = row.demarcacao;
    });

}
function edita()
{
    var id = sessionStorage.getItem('id');
    var dados = [];
    dados.push(document.getElementById("nome").value);
    if(document.getElementById("fornecedor").value != 0)
    {
        dados.push(document.getElementById("fornecedor").value);
    }
    else
    {
        alert("Selecione um fornecedor!");
        return;
    }
    dados.push(document.getElementById("unidade").value);
    dados.push(document.getElementById("quantidade").value);
    dados.push(document.getElementById("marca").value);
    dados.push(document.getElementById("valor_unitario").value);
    dados.push(document.getElementById("descricao").value);
    dados.push(document.getElementById("intervalo").value);
    dados.push(document.getElementById("demarcacao").value);
    db.run("update materia_prima set nome = '"+dados[0]+"', fornecedor = "+dados[1]+", unidade = '"+dados[2]+"', quantidade = "+dados[3]
    +", marca = '"+dados[4]+"', valor_unitario = "+dados[5]+", descricao = '"+dados[6]+"', intervalo = "+dados[7]+", demarcacao = '"+dados[8]+"' where codigo = "+id, ()=>
    {
        document.location.href = 'materias_primas.html';
        alert("Alterado!");
    });
}
function excluir()
{
    var id = sessionStorage.getItem('id');
    db.run("delete from materia_prima where codigo = "+id, ()=>
    {
        document.location.href = 'materias_primas.html';
        alert("Excluido");
    });
}
function fornecedores()
{
    var select = document.getElementById("fornecedor");
    db.each("SELECT nome, codigo as id, cpfcnpj FROM fornecedor", function(err, row) 
    {
        var option = document.createElement("option");
        option.text = row.id+" - "+row.nome+" ("+row.cpfcnpj+")";
        option.value = row.id;
        select.appendChild(option);
        faz_filtro_fornecedor();
    });
}
function jq()
{
    window.$ = window.jQuery = require('jquery');
    jQuery.fn.filterByText = function(textbox) 
    {
        return this.each(function() 
        {
            var select = this;
            var options = [];
            $(select).find('option').each(function() 
            {
                options.push({value: $(this).val(), text: $(this).text()});
            });
            $(select).data('options', options);
            $(textbox).bind('change keyup', function() 
            {
                var options = $(select).empty().scrollTop(0).data('options');
                var search = $(this).val().trim();
                var regex = new RegExp(search,"gi");
                $.each(options, function(i) 
                {
                    var option = options[i];
                    if(option.text.match(regex) !== null) 
                    {
                        $(select).append(
                        $('<option>').text(option.text).val(option.value)
                        );
                    }
                });
            });            
        });
    };   
}
function faz_filtro_fornecedor()
{
    // You could use it like this:
    $(function() 
    {
        $('#fornecedor').filterByText($('#filtro_fornecedores'));
    }); 
}
function faz_filtro_mp()
{
    // You could use it like this:
    $(function() 
    {
        $('#lista').filterByText($('#filtro_mp'));
    }); 
}
function muda_pagina()
{
    if(document.getElementById("lista").value != 0)
    {
        sessionStorage.setItem('id', document.getElementById("lista").value);
        document.location.href = 'altera_materia_prima.html';
    }
    else
    {
        alert("Selecione algum item!");
    }
}