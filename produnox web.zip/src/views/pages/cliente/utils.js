var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('dados_orcamento.sqlite3');
function cadastra()
{
    var dados = [];
    dados.push(document.getElementById("nome").value);
    dados.push(document.getElementById("cpf_cnpj").value);
    dados.push(document.getElementById("telefone").value);
    dados.push(document.getElementById("contato").value);
    dados.push(document.getElementById("email").value);
    dados.push(document.getElementById("wpp").value);
    dados.push(document.getElementById("end").value);
    var data = new Date(); 
    db.run("INSERT INTO cliente (nome, cpfcnpj, telefone, contato, data_registro, email, wpp, endereco) VALUES"
    +"('"+dados[0]+"','"+dados[1]+"','"+dados[2]+"','"+dados[3]+"', '"+data.toISOString()+"', '"+dados[4]+"', '"+dados[5]+"', '"+dados[6]+"');", ()=>
    {
        document.location.href = 'clientes.html';
        alert("Cadastrado!");
    });
}
function lista()
{
    var select = document.getElementById("lista");
    db.each("SELECT nome, codigo as id, cpfcnpj FROM cliente", function(err, row) 
    {
        var option = document.createElement("option");
        option.text = row.id+" - "+row.nome+" ("+row.cpfcnpj+")";
        option.value = row.id;
        select.appendChild(option);
        faz_filtro_cliente();
    });
}
function carrega_dados()
{
    var id = sessionStorage.getItem('id');
    db.each("SELECT * FROM cliente where codigo = "+id, function(err, row) 
    {
        document.getElementById("nome").value = row.nome;
        document.getElementById("cpf_cnpj").value = row.cpfcnpj;
        document.getElementById("telefone").value = row.telefone;
        document.getElementById("contato").value = row.contato;
        document.getElementById("data_registro").value = get_date(row.data_registro);
        document.getElementById("email").value = row.email;
        document.getElementById("wpp").value = row.wpp;
        document.getElementById("end").value = row.endereco;
    });

}
function edita()
{
    var id = sessionStorage.getItem('id');
    var dados = [];
    dados.push(document.getElementById("nome").value);
    dados.push(document.getElementById("cpf_cnpj").value);
    dados.push(document.getElementById("telefone").value);
    dados.push(document.getElementById("contato").value);
    dados.push(document.getElementById("email").value);
    dados.push(document.getElementById("wpp").value);
    dados.push(document.getElementById("end").value);
    db.run("update cliente set nome = '"+dados[0]+"', cpfcnpj = '"+dados[1]+"', telefone = '"+dados[2]+"', contato = '"+dados[3]
    +"', email = '"+dados[4]+"', wpp = '"+dados[5]+"', endereco = '"+dados[6]+"' where codigo = "+id, ()=>
    {
        alert("Editado!");
        document.location.href = 'clientes.html';
    });
}
function excluir()
{
    var id = sessionStorage.getItem('id');
    db.run("delete from materias_primas_do_orcamento where codigo_or = (select codigo from orcamento where cliente = "+id+");", ()=>
    {
        db.run("delete from orcamento where cliente = "+id+";", ()=>
        {
            db.run("delete from cliente where codigo = "+id, ()=>
            {
                alert("Excluido!");
                document.location.href = 'clientes.html';
            });
        });
    });
}
function get_date(data)
{
    date = new Date(data);
    year = date.getFullYear();
    month = date.getMonth()+1;
    dt = date.getDate();
    if (dt < 10) 
    {
        dt = '0' + dt;
    }
    if (month < 10) 
    {
        month = '0' + month; 
    }
    return (year+'-'+month+'-'+dt);
}
function muda_pagina()
{
    if(document.getElementById("lista").value != 0)
    {
        sessionStorage.setItem('id', document.getElementById("lista").value);
        document.location.href = 'altera_cliente.html';
    }
    else
    {
        alert("Selecione algum item!");
    }
}
window.onload = function() 
{
    lista();
    jq();
};
function jq()
{
    window.$ = window.jQuery = require('jquery');
    jQuery.fn.filterByText = function(textbox) 
    {
        return this.each(function() 
        {
            var select = this;
            var options = [];
            $(select).find('option').each(function() 
            {
                options.push({value: $(this).val(), text: $(this).text()});
            });
            $(select).data('options', options);
            $(textbox).bind('change keyup', function() 
            {
                var options = $(select).empty().scrollTop(0).data('options');
                var search = $(this).val().trim();
                var regex = new RegExp(search,"gi");
                $.each(options, function(i) 
                {
                    var option = options[i];
                    if(option.text.match(regex) !== null) 
                    {
                        $(select).append(
                        $('<option>').text(option.text).val(option.value)
                        );
                    }
                });
            });            
        });
    };   
}
function faz_filtro_cliente()
{
    // You could use it like this:
    $(function() 
    {
        $('#lista').filterByText($('#filtro_clientes'));
    }); 
}