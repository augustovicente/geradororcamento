var sqlite3 = require('sqlite3').verbose();
let shell = require('electron').shell;
var PDFDocument = require('pdfkit2');
var fs = require('fs');
const path = require('path');
const app = require('electron');
var dir = path.join(app.remote.app.getAppPath().replace(app.remote.app.getAppPath().substr(-18, 18), "")+'tmp');
if (!fs.existsSync(dir))
{
    fs.mkdirSync(dir);
}
var dir2 = dir+'/orcamentos';
if (!fs.existsSync(dir2))
{
    fs.mkdirSync(dir2);
}
var db = new sqlite3.Database('dados_orcamento.sqlite3');
function cria_doc(id)
{
    var doc = new PDFDocument(
    {
        margin: 10   
    });
    // create a document and pipe to a blob
    var diretorio = fs.createWriteStream(dir2+'/orcamento-'+id+'.pdf');
    doc.pipe(diretorio);
    doc.image(dir+'/Logo.PNG', 15, 0,
    {
        fit: [250, 300]
    });
    doc.fontSize(8).text('Rua Avelino José da Silva, 421 - Jardim Ana Rosa II - Cep: 86.183-773\nTel: (43)3253-5424 / Site: www.produnox.com.br - Cambé - Pr.', 
    285, 30);
    var data = new Date();
    doc.fontSize(15).text('Emissão: '+get_date(data.toISOString()), 55, 90);
    doc.fontSize(15).text('Orçamento nº: '+id, 270, 90);
    db.each("select o.valor_total, o.total_itens, o.forma_pagamento, o.imagem1, o.imagem2, c.nome, c.telefone, c.email from orcamento o inner join cliente c on "
    +"c.codigo = o.cliente where o.codigo = "+id, function(err, row)
    {
        var imagem1 = row.imagem1;
        var imagem2 = row.imagem2;
        var altura = 210;
        doc.fontSize(10).text('Cliente: '+(row.nome.length > 20 ? row.nome.substring(0, 20)+"..." : row.nome), 55, altura-90);
        doc.fontSize(10).text('E-mail: '+row.email, 270, altura-90);
        doc.fontSize(15).text('Valor Total: '+transform_to_preco(row.valor_total), 380, 701);
        doc.fontSize(10).text('Forma de pag.: '+row.forma_pagamento, 55, altura-60);
        doc.fontSize(10).text('Tel: '+ (row.telefone.length > 20 ? row.telefone.substring(0, 20)+"..." : row.telefone), 270, altura-60);
        altura += 10;
        doc.moveTo(0, altura-30).lineTo(700, altura-30).stroke() ;
        doc.fontSize(15).text('Produtos', 250, altura-10);
        altura += 20;
        var timer = 0;
        db.each("select pr.nome as nome, pr.codigo_or as cod from produto_orcamento pr inner join orcamento on pr.codigo_or = orcamento.codigo"
        +" where pr.codigo_or = "+id, function(err, row) 
        {
            setTimeout(() => 
            {
                doc.fontSize(12).text('Produto: '+row.nome, 60, altura);
                altura += 30;
                db.each("select mp.codigo as codigo, mp.nome, mpo.qtd as qtd, mp.valor_unitario as preco, mp.unidade as unidade, mp.especifica as especifica, "
                +"mp.demarcacao as demarcacao, mp.intervalo as intervalo"
                +" from materia_prima_do_produto mpo inner join materia_prima mp on mpo.codigo_mp = mp.codigo"
                +" where mpo.codigo_pr = "+row.cod, function(err, row) 
                {
                    if(row.especifica == 0)
                    {
                        if(altura >= 680 && altura < 710)
                        {
                            altura = 710;
                            doc.fontSize(10).text('Código: '+row.codigo, 60, altura);
                            doc.fontSize(10).text('Nome: '+(row.nome.length > 25 ? row.nome.substring(0, 25)+"..." : row.nome), 130, altura);
                            doc.fontSize(10).text('Quantidade: '+row.qtd +" "+(row.unidade.length > 25 ? row.unidade.substring(0, 25)+"..." : row.unidade), 340, altura);
                            altura += 30;
                        }
                        else
                        {
                            doc.fontSize(10).text('Código: '+row.codigo, 60, altura);
                            doc.fontSize(10).text('Nome: '+(row.nome.length > 25 ? row.nome.substring(0, 25)+"..." : row.nome), 130, altura);
                            doc.fontSize(10).text('Quantidade: '+row.qtd +" "+(row.unidade.length > 25 ? row.unidade.substring(0, 25)+"..." : row.unidade), 340, altura);
                            altura += 30;
                        }
                    }
                    else if(row.especifica == 1)
                    {
                        if(altura >= 680 && altura < 710)
                        {
                            altura = 710;
                            doc.fontSize(10).text('Código: '+row.codigo, 60, altura);
                            doc.fontSize(10).text('Nome: '+(row.nome.length > 25 ? row.nome.substring(0, 25)+"..." : row.nome), 130, altura);
                            doc.fontSize(10).text('Quantidade: '+row.qtd +" "+(row.unidade.length > 25 ? row.unidade.substring(0, 25)+"..." : row.unidade), 340, altura);
                            doc.fontSize(10).text(parseInt(parseFloat(row.qtd)/parseFloat(row.intervalo))+" "+row.demarcacao.substring(0, 10), 470, altura);
                            altura += 30;
                        }
                        else
                        {
                            doc.fontSize(10).text('Código: '+row.codigo, 60, altura);
                            doc.fontSize(10).text('Nome: '+(row.nome.length > 25 ? row.nome.substring(0, 25)+"..." : row.nome), 130, altura);
                            doc.fontSize(10).text('Quantidade: '+row.qtd +" "+(row.unidade.length > 25 ? row.unidade.substring(0, 25)+"..." : row.unidade), 340, altura);
                            doc.fontSize(10).text(parseInt(parseFloat(row.qtd)/parseFloat(row.intervalo))+" "+row.demarcacao.substring(0, 10), 470, altura);
                            altura += 30;
                        }
                    }
                });
            }, timer);
            timer += 500;
        });
        setTimeout(function()
        {
            if(imagem1 != "")
            {
                doc.image(row.imagem1, 40, altura+30, 
                {
                    fit: [250, 300]
                });
            }
            if(imagem2 != "")
            {
                doc.image(row.imagem2, 295, altura+30, 
                {
                    fit: [250, 300]
                });
            }
        }, 5000);
        alert("Pdf gerado em: file:///"+dir2+"/orcamento-"+id+".pdf");;
        setTimeout(function()
        {
            shell.openExternal(path.join("file:///"+dir2+"/orcamento-"+id+".pdf"));
            doc.end();
        }, 5500);
    });
    // end and display the document in the iframe to the right
}
function get_date(data)
{
    date = new Date(data);
    year = date.getFullYear();
    month = date.getMonth()+1;
    dt = date.getDate()+1;
    if (dt < 10) 
    {
        dt = '0' + dt;
    }
    if (month < 10) 
    {
        month = '0' + month; 
    }
    return (dt+'/'+month+'/'+year);
}
function get_date2(data)
{
    date = new Date(data);
    year = date.getFullYear();
    month = date.getMonth()+1;
    dt = date.getDate();
    if (dt < 10) 
    {
        dt = '0' + dt;
    }
    if (month < 10) 
    {
        month = '0' + month; 
    }
    return (year+'-'+month+'-'+dt);
}
function remover_item(id)
{
    db.run("delete from orcamento where codigo = "+id, ()=>
    {
        db.run("delete from materias_primas_do_orcamento where codigo_or = "+id+";");
        alert("Orçamento deletado!");
    });
}
function imprimir_orc(id)
{
    cria_doc(id);
}
function filtrar()
{
    if(document.getElementById("filtro").value == 0)
    {
        alert("Escolha um filtro!");
    }
    else
    {
        var tabela = document.getElementById("table");
        while(tabela.children[1]) 
        {
            tabela.removeChild(tabela.children[1]);
        }
        if(document.getElementById("filtro").value == 1)
        {
            if(!document.getElementById("row"+document.getElementById("date").value))
            {
                var table = document.getElementById("table");
                db.each("SELECT orcamento.codigo as id, data, total_itens, valor_total, cliente.nome as nome FROM orcamento inner join cliente on cliente.codigo"
                +" = orcamento.cliente where orcamento.data = '"+get_date(document.getElementById("date").value)+"'", function(err, row) 
                {
                    var row_table = document.createElement("tr");
                    row_table.id = "row"+document.getElementById("date").value;
                    var data = document.createElement("td");
                    var cliente = document.createElement("td");
                    var qtd = document.createElement("td");
                    var preco = document.createElement("td");
                    var excluir = document.createElement("td");
                    var imprimir = document.createElement("td");
                    data.innerHTML = row.data;
                    cliente.innerHTML = row.nome;
                    qtd.innerHTML = row.total_itens;
                    preco.innerHTML = transform_to_preco(row.valor_total);
                    excluir.innerHTML = "Excluir";
                    excluir.className = "remove"
                    excluir.onclick = function () 
                    {
                        remover_item(row.id);
                    };
                    imprimir.innerHTML = "Imprimir";
                    imprimir.className = "remove"
                    imprimir.onclick = function () 
                    {
                        imprimir_orc(row.id);
                    };
                    row_table.appendChild(data);
                    row_table.appendChild(cliente);
                    row_table.appendChild(qtd);
                    row_table.appendChild(preco);
                    row_table.appendChild(excluir);
                    row_table.appendChild(imprimir);
                    table.appendChild(row_table);
                });
            }
            else
            {
                alert("Já foi filtrado!");
            }
        }
        else if(document.getElementById("filtro").value == 2)
        {
            if(document.getElementById("cliente").value == 0)
            {
                alert("Escolha um cliente!");
            }
            else
            {
                if(!document.getElementById("row"+document.getElementById("cliente").value))
                {
                    var table = document.getElementById("table");  
                    db.each("SELECT orcamento.codigo as id, data, total_itens, valor_total, cliente.nome as nome FROM orcamento inner join cliente on cliente.codigo"
                    +" = orcamento.cliente where cliente.codigo = "+document.getElementById("cliente").value, function(err, row) 
                    {
                        var row_table = document.createElement("tr");
                        row_table.id = "row"+document.getElementById("cliente").value;
                        var data = document.createElement("td");
                        var cliente = document.createElement("td");
                        var qtd = document.createElement("td");
                        var preco = document.createElement("td");
                        var excluir = document.createElement("td");
                        var imprimir = document.createElement("td");
                        data.innerHTML = row.data;
                        cliente.innerHTML = row.nome;
                        qtd.innerHTML = row.total_itens;
                        preco.innerHTML = transform_to_preco(row.valor_total);
                        excluir.innerHTML = "Excluir";
                        excluir.className = "remove"
                        excluir.onclick = function () 
                        {
                            remover_item(row.id);
                        };
                        imprimir.innerHTML = "Imprimir";
                        imprimir.className = "remove"
                        imprimir.onclick = function () 
                        {
                            imprimir_orc(row.id);
                        };
                        row_table.appendChild(data);
                        row_table.appendChild(cliente);
                        row_table.appendChild(qtd);
                        row_table.appendChild(preco);
                        row_table.appendChild(excluir);
                        row_table.appendChild(imprimir);
                        table.appendChild(row_table);
                    });
                }
                else
                {
                    alert("Já foi filtrado!");
                }
            }
        }
    }
}
function carregar()
{
    var select = document.getElementById("cliente");
    db.each("SELECT nome, codigo as id, cpfcnpj FROM cliente", function(err, row) 
    {
        var option = document.createElement("option");
        option.text = row.id+" - "+row.nome+" ("+row.cpfcnpj+")";
        option.value = row.id;
        select.appendChild(option);
    });
    var data = new Date();
    data = get_date2(data.toISOString());
    document.getElementById("date").value = data;
    if(sessionStorage.getItem("imprimir"))
    {
        cria_doc(sessionStorage.getItem("imprimir"));
        sessionStorage.clear();
    }
}
function troca_filtro()
{
    if(document.getElementById("filtro").value == 1)
    {
        document.getElementById("date").className = "input1 teste2";
        document.getElementById("cliente").className = "input1 teste";
    }
    else if(document.getElementById("filtro").value == 2)
    {
        document.getElementById("cliente").className = "input1 teste2";
        document.getElementById("date").className = "input1 teste";
    }
}
function transform_to_preco(preco)
{
    var strPreco = "R$ " + parseFloat(preco).toFixed(2).toString().replace(".", ",");
    // retornando o resultado
    return strPreco;
}